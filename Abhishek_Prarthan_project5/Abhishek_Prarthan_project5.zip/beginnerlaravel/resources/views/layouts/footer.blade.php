
	

<footer class="page-footer font-small" style="bottom:0;width: 100%;"> 
    <!-- <span style="clear:both"></span> -->
        <div class= "container.fluid f p-4">
          <div class="row pt-3">
            <div class=" col-md-6 mb-4">
                    <h3 class = "text-center">&nbsp; Contactate con
                    &nbsp;<span class="active">Nosotros</span> </h3>
                    </div>
                    <div class="col-md-6 mb-4 ">
                    <form method="post" class="input-group text-center">
                    <input type="text" placeholder="Email" name="Email" class=" ip_f " pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>
                    <div class ="input-group-append">
                    <button class="f_button " name="submit" type="submit">ENVAR</button></div> </form> </div>
      </div>
      </div>
      <div class=" text-center hex-dark py-5" style="background-color: #000000;
    opacity: 0.8;">
   <a class="border  f_icons p-2 px-3 mr-4 d-none d-inline-block" href="mailto:info@genteyciudad.org"> <img style="height:20px; width:20px;" src="./images/Images/mail.png" title="Mail">
    </a>
   <a href="https://twitter.com/genteyciudadorg" class="border f_icons p-2 px-3 mr-4 d-none d-inline-block"><img style="height:20px; width:20px;" src="./images/Images/twitter.png" title="Twitter">
    </a>
    <a id="footer-link-contact" href="https://www.instagram.com/genteyciudadorg/" class="border f_icons p-2 px-3 mr-4 d-none d-inline-block"><img style="height:20px; width:20px;" src="./images/Images/instagram.png" title="Instagram">
    </a>
  </div>
    <div class="f_bottom footer-copyright p-3">
        <span class="active"><a href="http://www.diazapps.com/">DiazApps</a></span> &copy;&nbsp;
        <span style="opacity: 0.6;">2020 All Rights Reserved</span>
    </div>
    <div class="scroll_top"> 
      <a href="#top">&and;</a>
    </div>
  </footer>

