<!DOCTPE html>
<html>
<head>
    <title>View Events</title>
    <style type="text/css">
        .crsr-ptr:hover{
    background-color: #1e1e1e;
    opacity:0.4; 
    color:#ffffff;
        }
    </style>
</head>
<body class="mb-3 pd-3">
    <?php echo $__env->make('./layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br>
    <br>
    <div class="container-fluid">
          <div class="row txt-cntr">
        <div class="col-sm-12">
<button class="btn btn-primary" onclick="window.location='<?php echo e(url("EventList")); ?>'" >View All Events</button>&nbsp;&#8212;>&nbsp;<button class="btn btn-success" onclick="window.location='<?php echo e(url("EventUser")); ?>'" >Event User</button>&nbsp;&#8212;>&nbsp;<button class="btn btn-info" onclick="window.location='<?php echo e(url("registeredEvents")); ?>'" >Registered Events</button>        </div>
    </div>
     <br>
    <br>
    <br>
        <div class="row">

<div class="col-sm-12">

    <table class="table pt-3 mt-3">
        <thead>
            <tr>
        <td><strong>Event Id</strong></td>
        <td><strong>Event Name</strong></td>
        <td><strong>Event Description</strong></td>
        <td><strong>Event Location</strong></td>
        <td><strong>Event Date</strong></td>
        <td><strong>Event Time</strong></td>
        <td><strong>Register</strong></td>  
            </tr>
        </thead>
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="crsr-ptr" id="event" value="mk" onclick="window.location='<?php echo e(url("EventUser")); ?>',myFunction(<?php echo e($event->EventId); ?>)">
            <td><?php echo e($event->EventId); ?></td>
            <td><?php echo e($event->EventName); ?></td>
            <td><?php echo e($event->EventDescription); ?></td>
            <td><?php echo e($event->EventLocation); ?></td>
            <td><?php echo e($event->EventDate); ?></td>
            <td><?php echo e($event->EventTime); ?></td>
            <td>
                <a>UserDetails</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
            </div>
        </div>
    </div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
</body>
<!-- <div style="position: absolute;bottom: 0;width:100%;"> -->
<?php echo $__env->make('./layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- </div> -->
<script>

    function myFunction(item) {
        var id1 = document.getElementById('event').value;
    console.log('Hello',item);
    localStorage.setItem("eventId", item);
  // document.getElementById("myText").value = "Johnny Bravo";
}
</script>
</html><?php /**PATH C:\xampp\htdocs\beginnerlaravel\resources\views/EventList.blade.php ENDPATH**/ ?>