
<?php echo $__env->make('./layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- <div class="row justify-content-center">
              <div class="row txt-cntr">
        <div class="col-sm-12">
<button class="btn btn-primary" onclick="window.location='<?php echo e(url("adminevents")); ?>'" >View All Events</button>&nbsp;&#8212;>&nbsp;<button class="btn btn-success" onclick="window.location='<?php echo e(url("registerEvent")); ?>'" >Create Events</button>       </div>
    </div> -->
    <br>
    <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Dashboard</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <h3 class="txt-cntr">Welcome User</h3>
                        <div class="row">
                        <?php if(Route::has('register')): ?>
                        <div class="col-sm-6">
                            <button class="btn btn-primary" onclick="window.location='<?php echo e(url("adminevents")); ?>'" >View All Events</button>
                        </div>
                        <?php endif; ?>
                        <?php if(Route::has('register')): ?>
                        <div class="col-sm-6">
                            <button class="btn btn-success flt-rght" onclick="window.location='<?php echo e(url("registerEvent")); ?>'" >Create Event</button>
                        </div>
                        <?php endif; ?>
                        <?php if(Route::has('register')): ?>
                         <!--    <button onclick="window.location='<?php echo e(url("viewparticipants")); ?>'" >See All Participants</button> -->
                        <?php endif; ?>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php echo $__env->make('./layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beginnerlaravel\resources\views/adminhome.blade.php ENDPATH**/ ?>