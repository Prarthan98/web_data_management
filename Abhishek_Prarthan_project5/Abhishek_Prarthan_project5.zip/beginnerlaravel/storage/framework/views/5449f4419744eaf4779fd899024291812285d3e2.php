
<?php echo $__env->make('./layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row txt-cntr">
        <div class="col-sm-12">
<button class="btn btn-primary" onclick="window.location='<?php echo e(url("EventList")); ?>'" >View All Events</button>&nbsp;&#8212;>&nbsp;<button class="btn btn-success" onclick="window.location='<?php echo e(url("EventUser")); ?>'" >Event User</button>&nbsp;&#8212;>&nbsp;<button class="btn btn-info" onclick="window.location='<?php echo e(url("registeredEvents")); ?>'" >Registered Events</button>        </div>
    </div>
    <br>
    <br>
    <br>
    <div class="row">
        <div class="col-sm-12">
    <table  class="table mb-3 pd-3" border = "1">
        <tr>
            <td><strong>Event Name</td>
            <td><strong>Event Description</td>
            <td><strong>Event Location</td>
            <td><strong>Event Date</td>
            <td><strong>Event Time</td>
            <td><strong>Participants</td>
            <td><strong>Update</td>
            <td><strong>UnRegister</td>
        </tr>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($event->EventName); ?></td>
                <td><?php echo e($event->EventDescription); ?></td>
                <td><?php echo e($event->EventLocation); ?></td>
                <td><?php echo e($event->EventDate); ?></td>
                <td><?php echo e($event->EventTime); ?></td>
                <td><?php echo e($event->Participants); ?></td>
                <td>
                    <form action="/check" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="userId" value="<?php echo e(Auth::user()->id); ?>">
                        <input type="hidden" name="eventId" value="<?php echo e($event->EventId); ?>">
                        <button type="submit" onclick="myFunction(<?php echo e($event->EventId); ?>)" class="btn btn-primary"> <?php echo e(__('Update')); ?> </button>
                    </form>
                </td>
                <td><form action="/delete" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <input type="hidden" name="userId" value="<?php echo e(Auth::user()->id); ?>">
                        <input type="hidden" name="eventId" value="<?php echo e($event->EventId); ?>">
                        <button type="submit" class="btn btn-primary"> <?php echo e(__('UnRegister')); ?> </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</div>
</div>
</div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

    <script>

        function myFunction(item) {
            localStorage.setItem("uid", item);
            // document.getElementById("myText").value = "Johnny Bravo";
        }
    </script>
  
    <!-- <div style="position: absolute;bottom: 0;width: 100%;"> -->
    
<!-- </div> -->
 <?php echo $__env->make('./layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beginnerlaravel\resources\views/registeredEvents.blade.php ENDPATH**/ ?>