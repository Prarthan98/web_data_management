
 <?php echo $__env->make('./layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row txt-cntr">
        <div class="col-sm-12">
          <button class="btn btn-primary" onclick="window.location='<?php echo e(url("adminevents")); ?>'" >View All Events</button>&nbsp;&#8212;>&nbsp;
    <button class="btn btn-success" onclick="window.location='<?php echo e(url("registerEvent")); ?>'" >Create Event</button> 
        </div>
    </div>
    <br>
    <br>
    <br>

<div class="row">
    <div class="col-sm-12">
    <table class="table" border = "1">
        <tr>
            <td>Event Name</td>
            <td>Event Description</td>
            <td>Event Location</td>
            <td>Event Date</td>
            <td>Event Time</td>
            <td>Update</td>
            <td>Delete</td>
        </tr>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($event->EventName); ?></td>
                <td><?php echo e($event->EventDescription); ?></td>
                <td><?php echo e($event->EventLocation); ?></td>
                <td><?php echo e($event->EventDate); ?></td>
                <td><?php echo e($event->EventTime); ?></td>
                <td>
                    <form action="updateEvent" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="eventId" value="<?php echo e($event->EventId); ?>">
                        <button type="submit"  class="btn btn-primary"> <?php echo e(__('Update')); ?> </button>
                    </form>
                </td>
                <td><form action="/delete" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="eventId" value="<?php echo e($event->EventId); ?>">
                        <button type="submit" class="btn btn-primary"> <?php echo e(__('Delete')); ?> </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</div>
</div>
<br>
<br>
<br>
<br>
<br>
    <?php echo $__env->make('./layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
    </html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beginnerlaravel\resources\views/adminevents.blade.php ENDPATH**/ ?>