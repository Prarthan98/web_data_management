
	
	

	<div class="container-fluid" style="background-color: #fff !important;">
<div class="row no-gutters text-center">
	<div class="col-sm-2">
		<img onclick="window.location='<?php echo e(url("Inicio")); ?>'" style="width:100%;cursor:pointer;" src="./images/Images/i.jpg">
	</div>
	<div class="col-sm-1"></div>
	<div class="col-sm-1 mt-4  pt-4">
		<a  class="crsr-ptr" onclick="window.location='<?php echo e(url("Inicio")); ?>'">
			<h4 class="<?php echo e((request()->is('Inicio'))? 'active':''); ?>">Inicio</h4>
		</a>
	</div>
	<div class="col-sm-1 pt-4 mt-4">
		<a  class="crsr-ptr" onclick="window.location='<?php echo e(url("Nosotros")); ?>'">
			<h4 class="<?php echo e((request()->is('Nosotros'))? 'active':''); ?>">Nostros</h4>
		</a>
	</div>
	<div class="col-sm-1 pt-4 mt-4">
		<a class="crsr-ptr" onclick="window.location='<?php echo e(url("Equipos")); ?>'">
			<h4 class="<?php echo e((request()->is('Equipos'))? 'active':''); ?>">Equipos</h4>
		</a>
	</div>
	<div class="col-sm-1 pt-4 mt-4">
		<a class="dflt-clr crsr-ptr" href="http://pxp3770.uta.cloud/" target="_blank">
			<h4>Blog</h4>
		</a>
	</div>
	<div class="col-sm-1 pt-4 mt-4">
		<a class="crsr-ptr" onclick="window.location='<?php echo e(url("Contacto")); ?>'">
			<h4 class="<?php echo e((request()->is('Contacto'))? 'active':''); ?>">Contacto</h4>
		</a>
	</div>
<?php if(Route::has('login')): ?>
 <?php if(auth()->guard()->check()): ?>
	<div class="col-sm-1">
		<a class="dflt-clr crsr-ptr" href="<?php echo e(url('/home')); ?>">
			<h4 class="mt-4 pt-4" class="<?php echo e((request()->is('Home'))? 'active':''); ?>">Home</h4>
		</a>
		
	</div>
	<div class="col-sm-1">
		<a class="dflt-clr crsr-ptr" href="<?php echo e(url('/home')); ?>">
			<h4 class="mt-4 pt-4" href="<?php echo e(route('logout')); ?>"
                                      onclick="event.preventDefault();
                                                  document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?>(<?php echo e(Auth::user()->name); ?>)</h4>
		</a>
	</div>
	<?php else: ?>
	<div class="col-sm-2 pl-3 mt-4 pt-4">
		<a class="crsr-ptr dflt-clr" onclick="window.location='<?php echo e(url("login")); ?>'">
			<h4 class="<?php echo e((request()->is('login'))? 'active':''); ?>">Inicio de Sesion</h4>
		</a>
	</div>
	 <?php if(Route::has('register')): ?>
	 <div class="col-sm-1 pt-4 mt-4">
	 	<a class="crsr-ptr dflt-clr" onclick="window.location='<?php echo e(url("register")); ?>'">
	 		<h4 class="<?php echo e((request()->is('register'))? 'active':''); ?>">Registero</h4>
	 	</a>
	 </div>
	 <?php endif; ?>
     <?php endif; ?>
	 <?php endif; ?>
</div>
	</div>
	<body>




   <!-- <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?> -->
<!-- <button type="button" class="btn btn-danger">Danger</button> -->
<!-- <button type="button" class="btn btn-link">Link</button> -->

<?php echo $__env->make('layouts.bootstraphead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beginnerlaravel\resources\views///layouts/header.blade.php ENDPATH**/ ?>