<?php echo $__env->make('./layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="background-fade" style="background-image: url('../images/Images/homepage-one-banner.jpg');">
    <div class="sesion-cover">
        <div class="sesion-cover1">
            <br><br><br>
            <p class= "p-top">
              <span class="cover-heading active-page"> GENTE </span>
              <br>
            <i>
              <span class="cover-heading-sub">Y CIUDAD </span>
            </i>
            <br>
            </p>
            <p class="inicio-content">
            Buscamos marcar un punto de partida para la transformación de nuestras<br>
            dificultades y diferenciasencimientosfirmes que, desde las ciudades,<br>
            requieren nuestros países latinoamericanos para convertirse en los mejores<br>
            lugares para vivir, ya no solo por las bellezas y riquezas de nuestras tierras, sino<br>
            por lo decisión de su gente de aportar lo mejor de si para mejorar su calidad de<br>
            de vida y asegurar los derechos de las futures generaciones.<br>
            </p>
        </div>
    </div>
</div>
<div class="modalpopup">
    <h2>Inicio de
      <span class="active-page">
        <i>Sesion</i>
      </span>&nbsp; &nbsp;
       &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &times;</h2>
    <hr class="hr-form">
    <div class="form-container">
       <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>

        <label for="name">Correo</label>
        <input type="email" id="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Tu Correo" name="email" class="form-input">
         <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <br>
        <label for="password">Contraseña</label>
        <input type="password" placeholder="Tu Contraseña" class="form-input" required id="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" autocomplete="current-password">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <br >
        <!-- <hr class="hr-form"> -->
                           <div class="col-md-12">
                                <div class="form-check">

                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                     <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link txt flt-rght" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                                </div>
                            </div>
        <br>
        <button type="submit" class="sub-button"> <?php echo e(__('Login')); ?></button>
    </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beginnerlaravel\resources\views/auth/login.blade.php ENDPATH**/ ?>